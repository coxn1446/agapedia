CREATE TABLE user_autocreate_serial (
  uas_shard INT NOT NULL,
  uas_value INT NOT NULL,
  PRIMARY KEY(uas_shard)
);
