ALTER TABLE /*_*/recentchanges
    MODIFY rc_timestamp BINARY(14) NOT NULL;
