ALTER TABLE /*_*/iwlinks MODIFY iwl_title VARBINARY(255) NOT NULL default '';
