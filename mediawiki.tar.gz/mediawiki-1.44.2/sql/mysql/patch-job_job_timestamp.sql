ALTER TABLE /*_*/job
  MODIFY job_timestamp BINARY(14);