ALTER TABLE /*_*/image
    MODIFY img_timestamp BINARY(14) NOT NULL;
