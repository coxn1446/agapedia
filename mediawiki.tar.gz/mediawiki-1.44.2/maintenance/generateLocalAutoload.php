<?php

// The generateLocalAutoload script was renamed to generateAutoload in MW 1.41.
// This stub exists for backwards compatibility.
require_once __DIR__ . '/generateAutoload.php';
